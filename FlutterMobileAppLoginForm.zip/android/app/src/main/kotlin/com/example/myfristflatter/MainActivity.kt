package com.example.myfristflatter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
